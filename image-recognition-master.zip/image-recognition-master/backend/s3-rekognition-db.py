from __future__ import print_function

import boto3
from decimal import Decimal
import json
import urllib
import pymysql


rekognition = boto3.client('rekognition')
db_endpoint = 'image-recognition.cswc8ahqchpb.ap-southeast-2.rds.amazonaws.com'
username = 'admin'
password = 'recognition'
db_name = 'images'




# --------------- Helper Functions to call Rekognition APIs ------------------


def detect_faces(bucket, key):
    response = rekognition.detect_faces(Image={"S3Object": {"Bucket": bucket, "Name": key}})
    return response


def detect_labels(bucket, key):
    response = rekognition.detect_labels(Image={"S3Object": {"Bucket": bucket, "Name": key}}, MaxLabels=3)
    return response



# --------------- Main handler ------------------


def lambda_handler(event, context):
    '''Demonstrates S3 trigger that uses
    Rekognition APIs to detect faces, labels and index faces in S3 Object.
    '''
    #print("Received event: " + json.dumps(event, indent=2))

    # Get the object from the event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.unquote_plus(event['Records'][0]['s3']['object']['key'].encode('utf8'))

    try:
        # Calls rekognition DetectFaces API to detect faces in S3 object
        # response = detect_faces(bucket, key)

        # Calls rekognition DetectLabels API to detect labels in S3 object
        response = detect_labels(bucket, key)

        # Calls rekognition IndexFaces API to detect faces in S3 object and index faces into specified collection
        #response = index_faces(bucket, key)
        
        # Get tags from rekognition results 
        tag1= response['Labels'][0]['Name']
        tag2= response['Labels'][1]['Name']
        tag3= response['Labels'][2]['Name']
        
        print(tag1, tag2, tag3)
        
        try:
            connection = pymysql.connect(db_endpoint, user = username, passwd=password, db=db_name, connect_timeout=5)
        except pymysql.MySQLError as e:
            logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
            logger.error(e)
            sys.exit()
            
        cursor = connection.cursor()
        cursor.execute('insert into images (name,url,tag1,tag2,tag3) values (%s, %s, %s, %s, %s)',(key,"https://plann-image-recognition.s3-ap-southeast-2.amazonaws.com/"+key, tag1, tag2, tag3))
        connection.commit()
        
        # print data
        # cursor.execute("select * from images")
        # connection.commit()
        # for row in cursor:
        #     print(row)
        

        return response
    except Exception as e:
        print(e)
        print("Error processing object {} from bucket {}. ".format(key, bucket) +
              "Make sure your object and bucket exist and your bucket is in the same region as this function.")
        raise e
