from __future__ import print_function

import boto3
from decimal import Decimal
import json
import urllib
import pymysql


rekognition = boto3.client('rekognition')
db_endpoint = 'image-recognition.cswc8ahqchpb.ap-southeast-2.rds.amazonaws.com'
username = 'admin'
password = 'recognition'
db_name = 'images'


def lambda_handler(event, context):
    # Get the object from the event
    searchTag = event['queryStringParameters']['searchTag']

    try:
        connection = pymysql.connect(db_endpoint, user = username, passwd=password, db=db_name, connect_timeout=5)
    except pymysql.MySQLError as e:
        logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
        logger.error(e)
        sys.exit()
        
    cursor = connection.cursor()
    cursor.execute("select * from images where tag1 like %s or tag2 like %s or tag3 like %s", (searchTag, searchTag, searchTag))
    result = cursor.fetchall()
    print(result)
    if not result:
        return {
            "isBase64Encoded": False,
            'statusCode': 404,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body':json.dumps({
                'result': 'Not found'
            })
        }
    else:
        return {
            "isBase64Encoded": False,
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body':json.dumps({
                'result': result
            })
            
        }
    
