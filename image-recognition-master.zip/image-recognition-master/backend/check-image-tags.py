from __future__ import print_function

import boto3
from decimal import Decimal
import json
import urllib
import pymysql


rekognition = boto3.client('rekognition')
db_endpoint = 'image-recognition.cswc8ahqchpb.ap-southeast-2.rds.amazonaws.com'
username = 'admin'
password = 'recognition'
db_name = 'images'


def lambda_handler(event, context):
    # Get the object from the event
    fileName = event['queryStringParameters']['fileName']

    try:
        connection = pymysql.connect(db_endpoint, user = username, passwd=password, db=db_name, connect_timeout=5)
    except pymysql.MySQLError as e:
        logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
        logger.error(e)
        sys.exit()
        
    cursor = connection.cursor()
    cursor.execute("select * from images where name = %s limit 1", (fileName))
    result = cursor.fetchone()
    print(result[1],result[2])

    return {
        "isBase64Encoded": False,
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body':json.dumps({
            'id': result[0],
            'name': result[1],
            'url': result[2],
            'tag1': result[3],
            'tag2': result[4],
            'tag3': result[5]
        })
        
    }
    
