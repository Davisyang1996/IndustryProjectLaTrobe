import React, { useState } from "react";
import axios from "axios";
import CssBaseline from "@material-ui/core/CssBaseline";
import Container from "@material-ui/core/Container";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import GridList from "@material-ui/core/GridList";
import GridListTile from "@material-ui/core/GridListTile";
import GridListTileBar from "@material-ui/core/GridListTileBar";
import ListSubheader from "@material-ui/core/ListSubheader";
import IconButton from "@material-ui/core/IconButton";
import InfoIcon from "@material-ui/icons/Info";

import banner2 from "../banner2.png";

export default function Search() {
	const [input, setInput] = useState("");
	const [result, setResult] = useState([]);
	const [error, setError] = useState(undefined);

	const handleSubmit = (event) => {
		event.preventDefault();
		axios(
			"https://ggcudx4uwe.execute-api.ap-southeast-2.amazonaws.com/dev/search-images?searchTag=" +
				input
		)
			.then((res) => {
				setError(undefined);
				setResult(res.data.result);
			})
			.catch(function (error) {
				// handle error
				setResult([]);
				setError("Not found");
			});
	};

	return (
		<Container maxWidth="md">
			<CssBaseline />
			<form
				autoComplete="off"
				onSubmit={handleSubmit}
				style={{ marginBottom: "60px" }}
			>
				<TextField
					variant="outlined"
					margin="normal"
					required
					fullWidth
					onChange={(e) => setInput(e.target.value)}
					label="enter tag, example: dog"
				/>
				<Button type="submit" fullWidth variant="contained" color="primary">
					Search
				</Button>
			</form>
			{error}
			<GridList cellHeight={300}>
				{result.map((tile) => (
					<GridListTile key={tile[1]}>
						<img src={tile[2]} alt={tile[1]} />
						<GridListTileBar
							title={tile[1]}
							actionIcon={
								<IconButton>
									<InfoIcon />
								</IconButton>
							}
						/>
					</GridListTile>
				))}
			</GridList>
			<img
				src={banner2}
				style={{ maxWidth: "80%", marginTop: "100px", paddingLeft: "15%" }}
				alt="Banner"
			/>
		</Container>
	);
}
