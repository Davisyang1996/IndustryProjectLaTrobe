import React, { Component } from "react";
import axios from "axios";
import CssBaseline from '@material-ui/core/CssBaseline';
import Container from '@material-ui/core/Container';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';

export default class Home extends Component {
    state = {
        fileToUpload: undefined,
        uploadSuccess: undefined,
        error: undefined,
        tags: []
    };

    uploadFile() {
        // Getting the signed url
        axios(
            "https://ggcudx4uwe.execute-api.ap-southeast-2.amazonaws.com/dev/upload-to-s3?fileName=" + this.state.fileToUpload.name
        ).then(response => {
            // Getting the url from response
            const url = response.data.fileUploadURL;

            axios({
                method: "PUT",
                url: url,
                data: this.state.fileToUpload,
                headers: { "Content-Type": "multipart/form-data" }
            })
                .then(res => {
                    this.setState({
                        uploadSuccess: "File upload successfull",
                        error: undefined
                    });
                })
                .catch(err => {
                    this.setState({
                        error: "Error Occured while uploading the file",
                        uploadSuccess: undefined
                    });
                });
        });
    }

    checkTags() {
        axios.get('https://ggcudx4uwe.execute-api.ap-southeast-2.amazonaws.com/dev/check-tags?fileName=' + this.state.fileToUpload.name).then(res => {
            let tags = []
            tags.push(res.data.tag1, res.data.tag2, res.data.tag3)
            this.setState({ tags: tags })
        })
    }

    render() {
        return (
            <Container maxWidth="md">
                <CssBaseline />
                <form>
                    <div >
                        <Button variant="contained" component="label" fullWidth>
                            <input type="file"
                                onChange={e => {
                                    this.setState({
                                        fileToUpload: e.target.files[0]
                                    });
                                }}
                            />
                        </Button>
                        {this.state.fileToUpload ? (
                            <Button type="button" variant="contained" color="primary" fullWidth
                                onClick={e => {
                                    this.uploadFile();
                                }}
                            >
                                Upload your file
                                </Button>
                        ) : null}

                        <div>
                            <span>
                                {this.state.uploadSuccess
                                    ? <><Typography variant="h5" align="center" color="textPrimary" gutterBottom>File Upload Successfully</Typography>
                                        <Button type="button" variant="contained" color="primary" fullWidth
                                            onClick={e => {
                                                this.checkTags();
                                            }}
                                        >
                                            Check image recognition results
                                </Button>
                                        {this.state.tags.length !== 0 &&
                                            <ul>
                                                {this.state.tags.map(tag => (
                                                    <li key={tag}> <Typography variant="body1" color="textPrimary" gutterBottom>{tag}</Typography></li>
                                                ))}
                                            </ul>} </>
                                    : ""}
                            </span>
                        </div>



                    </div>
                </form>
            </Container>
        );
    }
}