import React from "react";
import { Switch, Route, Link } from "react-router-dom";
import Home from "./pages/home";
import Search from "./pages/search";
import logo from "./logo.jpeg";
import banner1 from "./banner1.png";

export default function App() {
	return (
		<>
			<header>
				<nav>
					<div style={{ position: "relative", marginBottom: "100px" }}>
						<img
							src={logo}
							style={{ maxWidth: "17%", position: "relative" }}
							alt="Logo"
						/>
						<img
							src={banner1}
							style={{ maxWidth: "83%", position: "absolute" }}
							alt="Banner"
						/>
					</div>
					<ul>
						<li>
							<Link to="/">Home</Link>
						</li>
						<li>
							<Link to="/search">Search</Link>
						</li>
					</ul>
				</nav>
			</header>
			<main>
				<Switch>
					<Route exact path="/" component={Home} />
					<Route path="/search" component={Search} />
				</Switch>
			</main>
		</>
	);
}
