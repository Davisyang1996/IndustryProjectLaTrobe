# image-recognition

A react app for identifying objects from an image and searching image tags using AWS. Upload Image from react UI. The image will be sent to API Gateway where it triggers the Lambda Function to store it in S3 Bucket. The stored image is sent to Amazon Recognition which will identify objects from the image, the image details will then be stored in RDS server.

![AWS diagram](/diagram.jpg)

## frontend

### after npm install run npm start

Runs the app in the development mode on port 3000.<br />
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## backend

All AWS lambda functions are stored under the folder
